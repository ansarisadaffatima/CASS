/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.io.*;
import java.net.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.security.MessageDigest;
import java.sql.*;
/**
 *
 * @author ABC
 */
public class server2 {
   
    public final static int SOCKET_PORT = 13267; 
  
    public static void main (String [] args ) throws IOException {
    String url = "jdbc:derby://localhost:1527/login";
    try
    {
               
        Connection conn = DriverManager.getConnection(url,"nbuser","nbuser");
                
        System.out.println("Connected to the database");
        MessageDigest md = MessageDigest.getInstance("SHA1");
         
        /*
         md.update("sadaf".getBytes()); 
      	 byte[] output = md.digest();
         System.out.println();
         System.out.println("SHA1(\""+"sadaf"+"\") =");
         String h1;
         h1=bytesToHex(output);
         System.out.println(h1);
         
         String sql = "INSERT INTO TABLE2 (PASSWORD) values (?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, h1);
            statement.executeUpdate();
        */
         
         ServerSocket servsock = null;
    	Socket sock = null;
      	servsock = new ServerSocket(SOCKET_PORT);
       	System.out.println("Waiting...");
        sock = servsock.accept();
        System.out.println("Accepted connection : " + sock);
        String str="",str2=""; 
        DataInputStream din=new DataInputStream(sock .getInputStream());  
        DataOutputStream dout=new DataOutputStream(sock .getOutputStream()); 
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
       

                        str2=din.readUTF();  
                        System.out.println("client says: "+str2); 
                        str=br.readLine();  
                        dout.writeUTF(str);  
                        dout.flush();  
                        str2=din.readUTF();  
                        System.out.println("client password: "+str2); 
                        
                        
                        String strSQL = "SELECT PASSWORD FROM TABLE2 where PASSWORD = ?";
                        PreparedStatement stmt = conn.prepareStatement(strSQL);
                        stmt.setString(1,str2);
        
                        ResultSet myResult = stmt.executeQuery();
                        if(myResult.next()){
                        System.out.println("Login Succesful! A record with the given user name and password exists");
                        
                        while(!str2.equalsIgnoreCase("stop")){  
                        str=br.readLine();  
                        dout.writeUTF(str);  
                        dout.flush(); 
                        str2=din.readUTF();  
                        System.out.println("client says: "+str2); 
                        } 
                        }                  
           
                        else {
                        System.out.println("Login Failed. No records exists with the given user name and password");
                        dout.writeUTF("stop"); 
                        }
        
     } catch (SQLException se)
            {
                System.out.println(se.getMessage());
            } 
            catch(Exception e){   
            }  
    }
     public static String bytesToHex(byte[] b) {
      char hexDigit[] = {'0', '1', '2', '3', '4', '5', '6', '7',
                         '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
      StringBuffer buf = new StringBuffer();
      for (int j=0; j<b.length; j++) {
         buf.append(hexDigit[(b[j] >> 4) & 0x0f]);
         buf.append(hexDigit[b[j] & 0x0f]);
      }
      return buf.toString();
   }
}
    
    
