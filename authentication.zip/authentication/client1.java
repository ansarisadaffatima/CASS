/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.io.*;
import java.net.*;
import javax.crypto.*;
import javax.crypto.spec.*;
/**
 *
 * @author ABC
 */
public class client1 {
        public final static int SOCKET_PORT = 13267;      // you may change this
        public final static String SERVER = "127.0.0.1";
   public static void main (String [] args ) throws IOException {
      	
       	Socket sock = null;
       	sock = new Socket(SERVER, SOCKET_PORT);
        
         DataInputStream din=new DataInputStream(sock.getInputStream());  
        DataOutputStream dout=new DataOutputStream(sock.getOutputStream());  
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      	System.out.println("Connecting...");
        
        
        String str="",str2="";  
        
        
        str2=br.readLine();  
        dout.writeUTF(str2);  
        dout.flush(); 
        str=din.readUTF();  
        System.out.println("server says: "+str);  
        if(str.equalsIgnoreCase("password")){
            str2=br.readLine();  
            dout.writeUTF(str2);  
            dout.flush();
            }
        
            str=din.readUTF();
            System.out.println("server says: "+str);
            while(!str.equalsIgnoreCase("stop")){ 
            str2=br.readLine();  
            dout.writeUTF(str2);  
            dout.flush();
            str=din.readUTF();  
            System.out.println("server says: "+str);
            }
         
        
        
   }
}
