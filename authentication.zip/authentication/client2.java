/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.io.*;
import java.net.*;

import java.security.MessageDigest;

/**
 *
 * @author ABC
 */
public class client2 {
     public final static int SOCKET_PORT = 13267;      // you may change this
        public final static String SERVER = "127.0.0.1";
   public static void main (String [] args ) throws IOException {
      	
       	Socket sock = null;
       	sock = new Socket(SERVER, SOCKET_PORT);
        try
        {
            MessageDigest md = MessageDigest.getInstance("SHA1");
            DataInputStream din=new DataInputStream(sock.getInputStream());  
            DataOutputStream dout=new DataOutputStream(sock.getOutputStream());  
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Connecting...");
         
            String str="",str2="";  
        
            str2=br.readLine(); 
            dout.writeUTF(str2);  
            dout.flush(); 
            str=din.readUTF();  
            System.out.println("server says: "+str);  
            if(str.equalsIgnoreCase("password")){
            str2=br.readLine(); 
            md.update(str2.getBytes()); 
            byte[] output = md.digest();
            System.out.println();
            System.out.println("SHA1(\""+str2+"\") =");
            String h1;
            h1=bytesToHex(output);
            System.out.println(h1);
            dout.writeUTF(h1);  
            dout.flush();
            }
        
            str=din.readUTF();
            System.out.println("server says: "+str);
            while(!str.equalsIgnoreCase("stop")){ 
            str2=br.readLine();  
            dout.writeUTF(str2);  
            dout.flush();
            str=din.readUTF();  
            System.out.println("server says: "+str);
            }
            
        } 
           catch(Exception e){   
            }
        
    }  
     public static String bytesToHex(byte[] b) {
      char hexDigit[] = {'0', '1', '2', '3', '4', '5', '6', '7',
                         '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
      StringBuffer buf = new StringBuffer();
      for (int j=0; j<b.length; j++) {
         buf.append(hexDigit[(b[j] >> 4) & 0x0f]);
         buf.append(hexDigit[b[j] & 0x0f]);
      }
      return buf.toString();
   }
}
